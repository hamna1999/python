file=input("Input the filename:")
f_extn=file.split(".")
print ("The extension of the file is:" +repr(f_extn[-1]))

