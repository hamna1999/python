color=input("ENTER COLORS SEPERATED BY COMAS:")
color_list= color.split(',')
print(color_list)
print("FIRST COLOR:",color_list[0])
print("LAST COLOR:",color_list[-1])

