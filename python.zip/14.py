color_list1={"white","black","red","blue"}
color_list2={"white","yellow","orange","grey"}
new_list=color_list1.difference(color_list2)
print (new_list)