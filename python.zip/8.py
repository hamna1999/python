str1=input("ENTER A STRING:")
a=str1[-1]
b=str1[1:-1]
c=str1[0]
print(a)
print(b)
print(c)
print("The output is:",a+b+c)

